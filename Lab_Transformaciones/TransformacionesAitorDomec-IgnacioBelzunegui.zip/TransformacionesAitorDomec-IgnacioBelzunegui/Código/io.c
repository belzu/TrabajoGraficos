#include "definitions.h"
#include "load_obj.h"
#include <GL/glut.h>
#include <stdio.h>

//Primero lo tenemos que compilar a un io.o a travesd e: gcc -c io.c

extern object3d * _first_object;
extern object3d * _selected_object;

extern GLdouble _ortho_x_min,_ortho_x_max;
extern GLdouble _ortho_y_min,_ortho_y_max;
extern GLdouble _ortho_z_min,_ortho_z_max;
int modo=0; //Variable usada para elegir entre rotacion(2), traslacion(1) o escalado(3)
int modo2=0; //Cambios respecto al mundo modo2=1 o respecto al objeto modo2=0
/**
 * @brief This function just prints information about the use
 * of the keys
 */
void print_help(){
    printf("Practica de Transformaciones. Este programa visualiza\n");
    printf("y modifica objetos en 3D.  \n\n");
    printf("\n\n");
    printf("FUNCIONES PRINCIPALES: \n");
    printf("<?>\t\t Visualizar ayuda \n");
    printf("<ESC>\t\t Salir del programa \n");
    printf("<F>\t\t Cargar un objeto\n");
    printf("<TAB>\t\t Cambiar la seleccion de un objeto cargado\n");
    printf("<DEL>\t\t Borrar el objeto seleccionado\n");
    printf("<CTRL + ->\t Aumentar el zoom\n");
    printf("<CTRL + +>\t Reducir el zoom\n");
    printf("<l / L>\t\t Activar transformaciones respecto al objeto\n");
    printf("<g / G>\t\t Activar transformaciones respecto al mundo\n");
    printf("<m / M>\t\t Activar la traslacion\n");
    printf("<b / B>\t\t Activar la rotacion\n");
    printf("<t / T>\t\t Activar el escalado\n");
    printf("\n\n");
}

//Guardamos el estado de la matriz actual (ya esta cargada) en la "pila" de estados de la lista de matrices
void guardar_estado()
{
    //Creamos una matriz auxiliar que apunte a la matrix de estado actual
    matrix_l *matrizaux;
    matrizaux = (matrix_l *) malloc(sizeof (matrix_l));
    matrizaux->next=_selected_object->matrix;
    //Guardamos la matriz cargada dentro de la auxiliar
    glGetDoublev(GL_MODELVIEW_MATRIX,matrizaux->matrix);
    //Hacemos que el objeto apunte a la matriz auxiliar
    _selected_object->matrix=matrizaux;   
}

void traslate(float a, float b, float c)
{
        if(_selected_object!=NULL) {
            //Hacemos el cambio respecto al objeto
            if(modo2==0){
                printf("Traslacion respecto al objeto\n");
                glMatrixMode(GL_MODELVIEW);
                glLoadMatrixd(_selected_object->matrix->matrix);
                glTranslatef(a, b, c);
                guardar_estado();
            }
            //Hacemos el cambio respecto al mundo
            else {
                printf("Traslacion respecto al mundo\n");
                glMatrixMode(GL_MODELVIEW);
                glLoadIdentity();
                glTranslatef(a, b, c);
                glMatrixMode(GL_MODELVIEW);
                glMultMatrixd(_selected_object->matrix->matrix);
                guardar_estado();
            }
        }
        else {
            printf("ERROR: No hay ningun objeto cargado!\n");
        }
}

void scale(float a, float b, float c)
{
    if(_selected_object!=NULL) {
    //Hacemos el cambio respecto al objeto
        if(modo2==0){
            printf("Escalado respecto al objeto\n");
            glMatrixMode(GL_MODELVIEW);
            glLoadMatrixd(_selected_object->matrix->matrix);
            glScalef(a, b, c);
            guardar_estado();
        }
        //Hacemos el cambio respecto al mundo
        else {
            printf("Escalado respecto al mundo\n");
            glMatrixMode(GL_MODELVIEW);
            glLoadIdentity();
            glScalef(a, b, c);
            glMatrixMode(GL_MODELVIEW);
            glMultMatrixd(_selected_object->matrix->matrix);
            guardar_estado();
        }
    }
    else {
        printf("ERROR: No hay ningun objeto cargado!\n");
    }
}


void rotate(float angle,float a, float b, float c)
{
    //Hacemos el cambio respecto al objeto
    if(_selected_object!=NULL) {
        if(modo2==0){
            printf("Rotacion respecto al objeto\n");
            glMatrixMode(GL_MODELVIEW);
            glLoadMatrixd(_selected_object->matrix->matrix);
            glRotatef(angle,a, b, c);
            guardar_estado();
        }
    //Hacemos el cambio respecto al mundo
    else {
            printf("Rotacion respecto al mundo\n");
            glMatrixMode(GL_MODELVIEW);
            glLoadIdentity();
            glRotatef(angle,a, b, c);
            glMatrixMode(GL_MODELVIEW);
            glMultMatrixd(_selected_object->matrix->matrix);
            guardar_estado();
        }   
    }
    else {
        printf("ERROR: No hay ningun objeto cargado!\n");
    }
}

void deshacer() {
    if(_selected_object!=NULL) {
        if(_selected_object->matrix->next!=0) {
            glMatrixMode(GL_MODELVIEW);
            matrix_l *borrar = _selected_object->matrix;                //Creamos una matriz que apunte al estado actual de la pila
            _selected_object->matrix=_selected_object->matrix->next;    //Hacemos que el objeto apunte al siguiente
            free(borrar);                                               //Eliminamos el antiguo estado de la pila
            glLoadMatrixd(_selected_object->matrix->matrix);            //Cargamos la matriz de nuevo
        }
        else {
            printf("ERROR: El objeto no tiene mas estados anteriores\n");
        }
    }
    else {
        printf("ERROR: No hay ningun objeto cargado!\n");
    }
}


void special_keyboard(unsigned char key, int x, int y) {
//void special_keyboard(int key, int x, int y) {
    switch(key) {
        case GLUT_KEY_UP:
            printf("Posicion del mouse: X:%i Y:%i\n",x,y);
            if(modo==1) {
                printf("Usted acaba de pulsar Flecha Arriba con el modo de Traslacion activado\n");
                traslate(0,KG_STEP_MOVE,0);
            }
            if(modo==2) {
                printf("Usted acaba de pulsar Flecha Arriba con el modo de Rotacion activado\n");
                rotate(KG_STEP_ROTATE,KG_STEP_MOVE, 0, 0); // KG_STEP_ROTATE define el angulo de rotacion; KG_STEP_MOVE define cuanto te mueves en el eje X al rotar (la rotación es en el eje X)
            }
                
            if(modo==3) {
                printf("Usted acaba de pulsar Flecha Arriba con el modo de Escalado activado\n");
                scale(1, KG_STEP_SCALE, 1);
            }     
        break;
        case GLUT_KEY_DOWN:
            printf("Posicion del mouse: X:%i Y:%i\n",x,y);
            if(modo==1) {
                printf("Usted acaba de pulsar Flecha Abajo con el modo de Traslacion activado\n");
                traslate(0,-KG_STEP_MOVE,0);
            }
            if(modo==2) {
                printf("Usted acaba de pulsar Flecha Abajo con el modo de Rotacion activado\n");
                rotate(KG_STEP_ROTATE,-KG_STEP_MOVE, 0, 0);
            }
                
            if(modo==3) {
                printf("Usted acaba de pulsar Flecha Abajo con el modo de Escalado activado\n");
                scale(1, 1/KG_STEP_SCALE, 1);
            }     
        break;
        case GLUT_KEY_LEFT:
            printf("Posicion del mouse: X:%i Y:%i\n",x,y);
            if(modo==1) {
                printf("Usted acaba de pulsar Flecha Izquierda con el modo de Traslacion activado\n");
                traslate(-KG_STEP_MOVE,0,0);
            }
            if(modo==2) {
                printf("Usted acaba de pulsar Flecha Izquierda con el modo de Rotacion activado\n");
                rotate(KG_STEP_ROTATE,0,-KG_STEP_MOVE, 0);
            }
                
            if(modo==3) {
                printf("Usted acaba de pulsar Flecha Izquierda con el modo de Escalado activado\n");
                scale(1/KG_STEP_SCALE,1, 1);
            }     
        break;
        case GLUT_KEY_RIGHT:
            printf("Posicion del mouse: X:%i Y:%i\n",x,y);
            if(modo==1) {
                printf("Usted acaba de pulsar Flecha Derecha con el modo de Traslacion activado\n");
                traslate(KG_STEP_MOVE,0,0);
            }
            if(modo==2) {
                printf("Usted acaba de pulsar Flecha Derecha con el modo de Rotacion activado\n");
                rotate(KG_STEP_ROTATE, 0, KG_STEP_MOVE, 0);
            }
                
            if(modo==3) {
                printf("Usted acaba de pulsar Flecha Derecha con el modo de Escalado activado\n");
                scale(KG_STEP_SCALE,1, 1);
            }     
        break;
        
    }
    
    glutPostRedisplay();
}


/**
 * @brief Callback function to control the basic keys
 * @param key Key that has been pressed
 * @param x X coordinate of the mouse pointer when the key was pressed
 * @param y Y coordinate of the mouse pointer when the key was pressed
 */
void keyboard(unsigned char key, int x, int y) {

    char* fname = malloc(sizeof (char)*128); /* Note that scanf adds a null character at the end of the vector*/
    int read = 0;
    object3d *auxiliar_object = 0;
    GLdouble wd,he,midx,midy;
    

    switch (key) {
    case 'f':
    case 'F':
        /*Ask for file*/
        printf("%s", KG_MSSG_SELECT_FILE);
        scanf("%s", fname);
        /*Allocate memory for the structure and read the file*/
        auxiliar_object = (object3d *) malloc(sizeof (object3d));
        read = read_wavefront(fname, auxiliar_object);
        switch (read) {
        /*Errors in the reading*/
        case 1:
            printf("%s: %s\n", fname, KG_MSSG_FILENOTFOUND);
            break;
        case 2:
            printf("%s: %s\n", fname, KG_MSSG_INVALIDFILE);
            break;
        case 3:
            printf("%s: %s\n", fname, KG_MSSG_EMPTYFILE);
            break;
        /*Read OK*/
        case 0:
            /*Insert the new object in the list*/
            auxiliar_object->next = _first_object;
            _first_object = auxiliar_object;
            _selected_object = _first_object;
            printf("%s\n",KG_MSSG_FILEREAD);
            break;
        }
        break;

    //-------------------------------------------------------------------------------------
    case 'g':
    case 'G':
        printf("Usted acaba de activar el sistema de referencia al del mundo\n");
        modo2=1;
        break;
    break;
    case 'l':
    case 'L':
        printf("Usted acaba de activar el sistema de referencia al del objeto\n");
        modo2=0;
        break;
    break;

    case 'b':
    case 'B':
        printf("Usted acaba de activar el modo de rotacion\n");
        modo=2;
        break;
    break;

    case 't':
    case 'T':
        printf("Usted acaba de activar el modo de escalado\n");
        modo=3;
        break;
    break;

    case 'm':
    case 'M':
        printf("Usted acaba de activar el modo de traslacion\n");
        modo=1;
        break;
    break;

    case 26: //Control z Tenemos que volver al estado anterior
        printf("Deshacer cambios\n");
        deshacer();
        /*
        if(_selected_object!=NULL) {
            if(_selected_object->matrix->next!=0) {
                deshacer();
                glMatrixMode(GL_MODELVIEW);
                matrix_l *borrar = _selected_object->matrix;//Creamos una matriz que apunte al estado actual de la pila
                _selected_object->matrix=_selected_object->matrix->next;//Hacemos que el objeto apunte al siguiente
                free(borrar);//Eliminamos el antiguo estado de la pila
                glLoadMatrixd(_selected_object->matrix->matrix); //Cargamos la matriz de nuevo
            }
            else {
                printf("ERROR: El objeto no tiene mas estados anteriores\n");
            }
        }
        else {
            printf("ERROR: No hay ningun objecto cargado!\n");
        }*/
    break;
    //-------------------------------------------------------------------------------------

    case 9: /* <TAB> */
        if(_selected_object!=NULL){
            _selected_object = _selected_object->next;
            /*The selection is circular, thus if we move out of the list we go back to the first element*/
            if (_selected_object == 0) _selected_object = _first_object;
        }
        else {
            printf("ERROR: No hay ningun objeto cargado!\n");
        }
        break;

    case 127: /* <SUPR> */
        if(_selected_object!=NULL){
            /*Erasing an object depends on whether it is the first one or not*/
            if (_selected_object == _first_object)
            {
                /*To remove the first object we just set the first as the current's next*/
                _first_object = _first_object->next;
                /*Once updated the pointer to the first object it is save to free the memory*/
                free(_selected_object);
                /*Finally, set the selected to the new first one*/
                _selected_object = _first_object;
            } else {
                /*In this case we need to get the previous element to the one we want to erase*/
                auxiliar_object = _first_object;
                while (auxiliar_object->next != _selected_object)
                    auxiliar_object = auxiliar_object->next;
                /*Now we bypass the element to erase*/
                auxiliar_object->next = _selected_object->next;
                /*free the memory*/
                free(_selected_object);
                /*and update the selection*/
                _selected_object = auxiliar_object;
            }
        }
        else {
            printf("ERROR: No hay ningun objeto cargado!\n");
        }
        break;

    case '-':
        if (glutGetModifiers() == GLUT_ACTIVE_CTRL){
            /*Increase the projection plane; compute the new dimensions*/
            wd=(_ortho_x_max-_ortho_x_min)/KG_STEP_ZOOM;
            he=(_ortho_y_max-_ortho_y_min)/KG_STEP_ZOOM;
            /*In order to avoid moving the center of the plane, we get its coordinates*/
            midx = (_ortho_x_max+_ortho_x_min)/2;
            midy = (_ortho_y_max+_ortho_y_min)/2;
            /*The the new limits are set, keeping the center of the plane*/
            _ortho_x_max = midx + wd/2;
            _ortho_x_min = midx - wd/2;
            _ortho_y_max = midy + he/2;
            _ortho_y_min = midy - he/2;
        }
        break;

    case '+':
          if (glutGetModifiers() == GLUT_ACTIVE_CTRL){
            /*Decrease the projection plane; compute the new dimensions*/
            wd=(_ortho_x_max-_ortho_x_min)*KG_STEP_ZOOM;//Multiplicamos por el factor del zoom (0.75) para reducir asi los valores de x e y en un cuarto
            he=(_ortho_y_max-_ortho_y_min)*KG_STEP_ZOOM;
            /*In order to avoid moving the center of the plane, we get its coordinates*/
            midx = (_ortho_x_max+_ortho_x_min)/2;
            midy = (_ortho_y_max+_ortho_y_min)/2;
            /*The the new limits are set, keeping the center of the plane*/
            _ortho_x_max = midx + wd/2;
            _ortho_x_min = midx - wd/2;
            _ortho_y_max = midy + he/2;
            _ortho_y_min = midy - he/2;
        }
        break;

    case '?':
        print_help();
        break;

    case 27: /* <ESC> */
        exit(0);
        break;

    default:
        /*In the default case we just print the code of the key. This is usefull to define new cases*/
        printf("%d %c\n", key, key);
    }
    /*In case we have do any modification affecting the displaying of the object, we redraw them*/
    glutPostRedisplay();
}

